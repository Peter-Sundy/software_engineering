package com.neu.staff.operator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JFrame;

import static com.neu.staff.operator.Constant.IMAGE_FILENAME;

public class interface_begin {
    JFrame frame = new JFrame("begin");
    JButton button0 = new JButton("Exit the System");
    JButton button1= new JButton("I'm an normal employee");
    JButton button2= new JButton("I'm an manager");
    JPanel p1 = new JPanel();
    JLabel lab1 = new JLabel();
    //File file = new File(interface_begin.class.getResource("/1.png").getFile());
    ImageIcon img = new ImageIcon(IMAGE_FILENAME);//图片路径
    public interface_begin(){
        lab1.setIcon(img);
        //label的大小设置为ImageIcon,否则显示不完整
        lab1.setBounds(10, 10, img.getIconWidth(), img.getIconHeight());
        p1.setLayout(null);
        p1.add(lab1);
        p1.add(button0);
        p1.add(button1);
        p1.add(button2);
        button0.setBounds(78,510,260,30);
        button1.setBounds(78,470,260,30);
        button2.setBounds(78,430,260,30);
        frame.add(p1,BorderLayout.CENTER);
        frame.setSize(434,600);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        button0.addActionListener(actionEvent ->{
            frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );
        });

        button1.addActionListener(actionEvent ->{
            interface_login2 demo = new interface_login2();
            demo.show();
        });

        button2.addActionListener(actionEvent ->{
            interface_login demo = new interface_login();
            demo.show();
        });
    }
    public void show() { frame.setVisible(true); }
}