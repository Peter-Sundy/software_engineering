package com.neu.staff.operator;

import com.neu.staff.user.Employee;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.io.IOException;

public class message {
    public static EmployeeSystem test1 = new EmployeeSystem();
    JFrame frame = new JFrame("leave application");
    JLabel a1 = new JLabel("Content:");
    JLabel a2 = new JLabel("Title:");
    JTextArea b1 = new JTextArea();
    JTextField b2 = new JTextField();
    JButton button = new JButton("message");
    JPanel p1 = new JPanel();
    public message(Employee etest){
        p1.setLayout(null);
        p1.add(a1);
        p1.add(b1);
        p1.add(a2);
        p1.add(b2);

        p1.add(button);
        a1.setBounds(40,50,150,30);
        b1.setBounds(100,60,200,280);
        a2.setBounds(55,25,80,30);
        b2.setBounds(100,25,200,30);
        button.setBounds(140,370,100,30);
        b1.setLineWrap(true);
        frame.add(p1, BorderLayout.CENTER);
        frame.setSize(400,500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        button.addActionListener(actionEvent ->{
            String content = b1.getText();
            String title = b2.getText();
            try {
                test1.message(etest,title,content);
            } catch (IOException e) {
                e.printStackTrace();
            }
            frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );

        });
    }
    public void show() { frame.setVisible(true); }
}
