package com.neu.staff.operator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.io.IOException;

import static com.neu.staff.operator.Manager_menu.demo_begin;
import static com.neu.staff.operator.interface_login.heng;

public class staff_menu {
    JFrame frame = new JFrame("staff menu");
    JButton button0 = new JButton("Go Back Main Menu");
    JButton button1= new JButton("Register by punching card");
    JButton button2= new JButton("Quit by punching card");
    JButton button3 = new JButton("View Check-in Information");
    JButton button4 = new JButton("Ask for leave");
    JButton button5 = new JButton("View MessageBoard");
    JPanel p1 = new JPanel();

    public staff_menu() {
        p1.setLayout(null);
        p1.add(button0);
        p1.add(button1);
        p1.add(button2);
        p1.add(button3);
        p1.add(button4);
        p1.add(button5);
        button1.setBounds(45,35,300,50);
        button2.setBounds(45,125,300,50);
        button3.setBounds(45,215,300,50);
        button4.setBounds(45,305,300,50);
        button5.setBounds(45,395,300,50);
        button0.setBounds(45,485,300,50);
        frame.add(p1, BorderLayout.CENTER);
        frame.setSize(400, 615);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        button0.addActionListener(actionEvent -> {
            frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );
            //demo_begin.show();
        });
        button1.addActionListener(actionEvent -> {
            try {
                heng.attend();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        button2.addActionListener(actionEvent -> {
            try {
                heng.quit();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        button3.addActionListener(actionEvent -> {
            try {
                heng.getInformation();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        button4.addActionListener(actionEvent -> {
                ask_for_leave ask_for_leave_demo=new ask_for_leave(heng.getEmployee());
                ask_for_leave_demo.show();
        });
        button5.addActionListener(actionEvent ->{
            message_board demo9 = null;
            try {
                demo9 = new message_board();
            } catch (IOException e) {
                e.printStackTrace();
            }
            demo9.show();
        });

    }
    public void show() {
        frame.setVisible(true);
    }
}
