package com.neu.staff.operator;

/**
 * This class defines some important constants.
 * @author BlankSpace
 * @version 2.0
 * @time 2019/7/13
 */
public class Constant {
    //All three files' split character
    public static final String SPLIT_CHARACTER = "#";
    //file "History.txt"'s path
    public static final String HISTORY_FILENAME = "src/com/neu/staff/file/History.txt";
    //file "ManagerInfo.txt"'s path
    public static final String MANAGER_FILENAME = "src/com/neu/staff/file/ManagerInfo.txt";
    //file "Staff.txt"'s path
    public static final String EMPLOYEE_FILENAME = "src/com/neu/staff/file/Staff.txt";
    //file "1.png"'s path
    public static final String IMAGE_FILENAME = "src/com/neu/staff/file/1.png";
    //file "LeaveApplication.txt"'s path
    public static final String LEAVE_FILENAME = "src/com/neu/staff/file/LeaveApplication.txt";
    //file "MessageBoard.txt"'s path
    public static final String BOARD_FILENAME = "src/com/neu/staff/file/MessageBoard.txt";
//    Not used in this version
//    public static final int    LIMIT_YEAR_ADD = 6;
}
