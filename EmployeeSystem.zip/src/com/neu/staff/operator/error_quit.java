package com.neu.staff.operator;

import javax.swing.*;
import java.awt.*;

public class error_quit {
    JFrame frame = new JFrame("Exception");
    JLabel a1 = new JLabel("You haven't attended today!");
    JPanel p1 = new JPanel();
    public error_quit(){
        p1.setLayout(new GridLayout(1,1));
        p1.add(a1);
        frame.add(p1);
        frame.setSize(200,100);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    public void show() {
        frame.setVisible(true);
    }
}
