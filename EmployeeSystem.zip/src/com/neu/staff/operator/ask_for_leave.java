package com.neu.staff.operator;

import com.neu.staff.user.Employee;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.io.IOException;

public class ask_for_leave {
    public static EmployeeSystem test1 = new EmployeeSystem();
    JFrame frame = new JFrame("leave application");
    JLabel a1 = new JLabel("Please enter a reason:");
    JLabel a2 = new JLabel("Start time:");
    JLabel a3 = new JLabel("End time:");
    JTextArea b1 = new JTextArea();
    JTextField b2 = new JTextField();
    JTextField b3 = new JTextField();
    JButton button = new JButton("submit");
    JPanel p1 = new JPanel();
    public ask_for_leave(Employee etest){
        p1.setLayout(null);
        p1.add(a1);
        p1.add(b1);
        p1.add(a2);
        p1.add(b2);
        p1.add(a3);
        p1.add(b3);
        p1.add(button);
        a1.setBounds(100,25,150,30);
        b1.setBounds(100,55,200,150);
        a2.setBounds(25,240,80,30);
        a3.setBounds(25,290,80,30);
        b2.setBounds(100,240,200,30);
        b3.setBounds(100,290,200,30);
        button.setBounds(160,370,80,30);
        b1.setLineWrap(true);
        frame.add(p1, BorderLayout.CENTER);
        frame.setSize(400,500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        button.addActionListener(actionEvent ->{
            String reason = b1.getText();
            String starttime = b2.getText();
            String endtime = b3.getText();
            try {
                test1.askforLeave(etest,reason,starttime,endtime);
            } catch (IOException e) {
                e.printStackTrace();
            }
            frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );

        });
    }
    public void show() { frame.setVisible(true); }
}
