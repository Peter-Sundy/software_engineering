package com.neu.staff.operator;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

import static com.neu.staff.operator.Constant.SPLIT_CHARACTER;

public class Manager_query1 {
    JFrame frame = new JFrame("information");
    JTextArea text1 = new JTextArea("");
    public  Manager_query1() throws IOException {
        frame.setLayout(null);
        frame.setSize(400, 500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        String ss = "";
        var array = new String[10];
        for (String line : IOController.readHistory()) {
            array = line.split(SPLIT_CHARACTER);
            ss=ss+array[0] + ": " + array[2] + "/" + array[3] + "/" + array[1]
                    + ", Start Time: " + array[4] + ":" + array[5] + ":" + array[6]
                    + ", End Time: " + array[7] + ":" + array[8] + ":" + array[9]+"\r\n";
            /*System.out.println(array[0] + ": " + array[2] + "/" + array[3] + "/" + array[1]
                    + ", Start Time: " + array[4] + ":" + array[5] + ":" + array[6]
                    + ", End Time: " + array[7] + ":" + array[8] + ":" + array[9]);*/
        }
        text1.setText(ss);
        //text1.setLineWrap(true);
        JScrollPane sp=new JScrollPane(text1);
        text1.setEditable(false);
        frame.setContentPane(sp);
    }
    public void show() { frame.setVisible(true); }
}
