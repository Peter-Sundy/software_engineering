package com.neu.staff.operator;

import javax.swing.*;
import java.awt.*;

public class notattend {
    JFrame frame = new JFrame("information");
    JLabel a1 = new JLabel("Warning: You haven't attended today!");
    JPanel p1 = new JPanel();
    public notattend(){
        p1.setLayout(new GridLayout(1,1));
        p1.add(a1);
        frame.add(p1);
        frame.setSize(200,100);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    public void show() {
        frame.setVisible(true);
    }
}
