package com.neu.staff.operator;

import javax.swing.*;
import java.awt.*;

public class success_quit {
    JFrame frame = new JFrame("successful");
    JLabel a1 = new JLabel("  quit successfully!");
    JPanel p1 = new JPanel();
    public success_quit(){
        p1.setLayout(new GridLayout(1,1));
        p1.add(a1);
        frame.add(p1);
        frame.setSize(200,100);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    public void show() {
        frame.setVisible(true);
    }
}
