package com.neu.staff.operator;

import com.neu.staff.user.Company;
import com.neu.staff.user.Employee;
import com.neu.staff.user.Manager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.io.FileReader;
import java.io.IOException;
import java.util.Calendar;
import java.util.Scanner;

import static com.neu.staff.operator.Constant.EMPLOYEE_FILENAME;

public class interface_login {
    public static EmployeeSystem heng = new EmployeeSystem();
    JFrame frame = new JFrame("login");
    JLabel a1 = new JLabel("id");
    JLabel a2 = new JLabel("password");
    JTextField b1 = new JTextField();
    JPasswordField b2 = new JPasswordField();
    JButton button = new JButton("OK");
    JPanel p1 = new JPanel();
    public interface_login(){
        p1.setLayout(null);
        p1.add(a1);
        p1.add(b1);
        p1.add(a2);
        p1.add(b2);
        p1.add(button);
        a1.setBounds(40,25,35,30);
        b1.setBounds(100,25,200,30);
        a2.setBounds(25,65,80,30);
        b2.setBounds(100,65,200,30);
        button.setBounds(160,110,80,30);
        frame.add(p1,BorderLayout.CENTER);
        frame.setSize(400,200);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        b1.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent keyEvent) {

            }

            @Override
            public void keyPressed(KeyEvent keyEvent) {

                    if (keyEvent.getKeyCode()==KeyEvent.VK_ENTER) {
                        String id = b1.getText();
                        String password = b2.getText();
                        try {
                            heng.register1(id,password);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );
                    }

            }

            @Override
            public void keyReleased(KeyEvent keyEvent) {

            }
        });
        b2.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent keyEvent) {

            }

            @Override
            public void keyPressed(KeyEvent keyEvent) {
                    if (keyEvent.getKeyCode()==KeyEvent.VK_ENTER) {
                        String id = b1.getText();
                        String password = b2.getText();
                        try {
                            heng.register1(id,password);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );
                    }
            }

            @Override
            public void keyReleased(KeyEvent keyEvent) {

            }
        });
        button.addActionListener(actionEvent ->{
            String id = b1.getText();
            String password = b2.getText();
            try {
                heng.register1(id,password);
            } catch (IOException e) {
                e.printStackTrace();
            }
            frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );

        });
    }
    public void show() { frame.setVisible(true); }
}

