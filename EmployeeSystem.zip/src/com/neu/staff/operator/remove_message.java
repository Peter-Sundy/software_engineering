package com.neu.staff.operator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.io.IOException;

import static com.neu.staff.operator.interface_login.heng;

public class remove_message {
    JFrame frame = new JFrame("remove message");
    JLabel a1 = new JLabel("input title");
    JTextField b1 = new JTextField("");
    JButton button = new JButton("OK");
    JPanel p1 = new JPanel();
    public  remove_message(){
        p1.setLayout(new GridLayout(3, 1));
        p1.add(a1);
        p1.add(b1);
        p1.add(button);
        frame.add(p1);
        frame.setSize(500, 300);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        b1.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent keyEvent) {

            }

            @Override
            public void keyPressed(KeyEvent keyEvent) {
                if(keyEvent.getKeyCode()==KeyEvent.VK_ENTER)
                {
                    String title = b1.getText();
                    try {
                        heng.Deletemessage(title);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );

                }
            }

            @Override
            public void keyReleased(KeyEvent keyEvent) {

            }
        });
        button.addActionListener(actionEvent -> {
            String title = b1.getText();
            try {
                heng.Deletemessage(title);
            } catch (IOException e) {
                e.printStackTrace();
            }
            frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );
        });
    }
    public void show() { frame.setVisible(true); }
}
