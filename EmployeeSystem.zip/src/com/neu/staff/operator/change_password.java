package com.neu.staff.operator;

import com.neu.staff.user.Employee;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

import static com.neu.staff.operator.interface_login.heng;

public class change_password {
    private  String old_passsword;
    private  String new1_passsword;
    private  String new2_passsword;
    JFrame Jame_changePassword = new JFrame("change password");
    JLabel a1 = new JLabel("Please enter your password");
    JLabel a2 = new JLabel("Please enter your new password");
    JLabel a3 = new JLabel("Please enter your new password");
    JTextField b1 = new JTextField("");
    JTextField b2 = new JTextField("");
    JTextField b3 = new JTextField("");
    JButton button = new JButton("OK");
    JPanel p1 = new JPanel();
    public change_password (Employee test)
    {
        p1.setLayout(new GridLayout(7, 1));
        p1.add(a1);
        p1.add(b1);
        p1.add(a2);
        p1.add(b2);
        p1.add(a3);
        p1.add(b3);
        p1.add(button);
        Jame_changePassword.add(p1);
        Jame_changePassword.setSize(300, 400);
        Jame_changePassword.setLocationRelativeTo(null);
        Jame_changePassword.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        button.addActionListener(actionEvent -> {
            try {

                old_passsword = b1.getText();
                new1_passsword = b2.getText();
                new2_passsword = b3.getText();
                heng.changePassword(old_passsword,new1_passsword,new2_passsword,test);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
    public void show() { Jame_changePassword.setVisible(true); }
}
