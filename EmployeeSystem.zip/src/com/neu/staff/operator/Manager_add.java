package com.neu.staff.operator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.io.IOException;

import static com.neu.staff.operator.interface_login.heng;

public class Manager_add {
    JFrame frame = new JFrame("add");
    JLabel a1 = new JLabel("input id");
    JLabel a2 = new JLabel("input name");
    JTextField b1 = new JTextField("");
    JTextField b2 = new JTextField("");
    JButton button = new JButton("OK");
    JPanel p1 = new JPanel();
    public  Manager_add(){
        p1.setLayout(new GridLayout(5, 1));
        p1.add(a1);
        p1.add(b1);
        p1.add(a2);
        p1.add(b2);
        p1.add(button);
        frame.add(p1);
        frame.setSize(500, 300);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        b1.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent keyEvent) {

            }

            @Override
            public void keyPressed(KeyEvent keyEvent) {
                if (keyEvent.getKeyCode()==KeyEvent.VK_ENTER)
                {
                    String id = b1.getText();
                    String name = b2.getText();
                    try {
                        heng.addNewEmployee1(id,name);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );
                }
            }

            @Override
            public void keyReleased(KeyEvent keyEvent) {

            }
        });
        b2.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent keyEvent) {

            }

            @Override
            public void keyPressed(KeyEvent keyEvent) {
                if (keyEvent.getKeyCode()==KeyEvent.VK_ENTER)
                {
                    String id = b1.getText();
                    String name = b2.getText();
                    try {
                        heng.addNewEmployee1(id,name);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );
                }
            }

            @Override
            public void keyReleased(KeyEvent keyEvent) {

            }
        });
        button.addActionListener(actionEvent -> {
                String id = b1.getText();
                String name = b2.getText();
                try {
                    heng.addNewEmployee1(id,name);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );
        });

    }
    public void show() { frame.setVisible(true); }
}
