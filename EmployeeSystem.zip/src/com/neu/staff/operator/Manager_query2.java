package com.neu.staff.operator;

import com.neu.staff.user.Company;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

import static com.neu.staff.operator.Constant.SPLIT_CHARACTER;
import static com.neu.staff.operator.interface_login.heng;

public class Manager_query2 {
    JFrame frame = new JFrame("information");
    JTextArea text1 = new JTextArea("");

    public  Manager_query2() throws IOException {
        frame.setLayout(null);

        frame.setSize(700, 500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        String ss = heng.viewInformation();
        text1.setText(ss);
        //text1.setLineWrap(true);
        JScrollPane sp=new JScrollPane(text1);
        text1.setEditable(false);
        frame.setContentPane(sp);
    }
    public void show() { frame.setVisible(true); }
}
