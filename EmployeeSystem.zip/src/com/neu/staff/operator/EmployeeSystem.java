package com.neu.staff.operator;

import java.io.IOException;

import static com.neu.staff.operator.Constant.*;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

import com.neu.staff.user.*;

/**
 * EmployeeSystem's main class, which can control this system.
 * System will ensure your identity first.
 * enter "0" if you want to exit.
 * enter "1" if you are a normal employee.
 * enter "2" if you are a manager.
 * After registering, you can do all things what you can do based on your identity.
 * Note: employees don't have their own password, however, managers must use their own password to register.
 * When employee execute this program, he will be in a dead loop unless entering "0".
 * enter "1", employee can register.
 * enter "2", employee can quit(Not exiting from this system).
 * enter "3", employee can get his information about punching card.
 * If you are a manager, you can do more things:
 * enter "4", manager can view all employees' information.
 * enter "5", manager can view all employees' attendance information.
 * enter "6", manager can add one single employee.
 * enter "7", manager can remove one single employee.
 * enter "8", manager can change his password.
 * If you are a manager, you must register as a manager;
 * instead, if you aren't a manager and you are an employee, you must register as an employee.
 * In this class, most functions are defined as private because of encapsulation.
 * This class import static com.operator.IOController class.
 * @author BlankSpace
 * @version 2.0
 * @time 2020/3/13
 */
public class EmployeeSystem {

    //create a scanner to get user's input in the system.
    private Scanner scanner;
    //one-one relationship.
    private Company company;
    //create a calendar to get time and control time in this system.
    private Calendar calendar;
    //create an employee to restore an employee who has registered and hasn't been quit.
    private Employee landingEmployee;

    //initialization block
    {
        calendar = Calendar.getInstance();
        scanner = new Scanner(System.in);
        company = Company.getInstance();
        try (var reader = new Scanner(new FileReader(EMPLOYEE_FILENAME))) {
            var line = reader.nextLine();
            while (reader.hasNextLine()) {
                line = reader.nextLine();
                var array = line.split("#");
                Employee newEmployee;
                if (Boolean.parseBoolean(array[array.length-1]) == true) {
                    newEmployee = new Manager(array[0], array[1], Integer.parseInt(array[2]),
                            Integer.parseInt(array[3]), Integer.parseInt(array[4]),
                            IOController.readPassword(array[0]));
                } else {
                    newEmployee = new Employee(array[0], array[1], Integer.parseInt(array[2]),
                            Integer.parseInt(array[3]), Integer.parseInt(array[4]));
                }
                company.initializeEmployee(newEmployee);
            }
        } catch (NumberFormatException numberFormatException) {
            numberFormatException.printStackTrace();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    //main()
    public static void main(String[] args) throws IOException, InterruptedException {
        var system = new interface_begin();
        system.show();
    }

    /**
     * The main() call this function to run.
     * The execution is in a dead cycle unless input special things.
     * @throws IOException
     */

/*    public void run() throws IOException {

            register(identity);
            if (landingEmployee != null) {
                runUser(identity);
            }
        }
    }
*/
    //to ensure the user's identity.
 /*   private int getIdentity() throws IOException {
        while(true) {
            try {
                System.out.println();
                printIdentityChoiceMenu();
                var choice = Integer.parseInt(scanner.next());
                System.out.println();
                if (0 <= choice && choice <= 2) {
                    return choice;
                }
                System.out.println("Invalid choice:  " + choice);
            } catch (NumberFormatException exception) {
                System.out.println(exception);
            }
        }
    }
  */
  /*  private void runUser(int identity) throws IOException {
        //use flag to ensure we can break outer cycle easily.
        flag:
        for(var choice = this.getChoice(identity); ; choice = this.getChoice(identity)) {
            switch (choice) {
                case 0:
                    this.landingEmployee = null;
                    break flag;
                case 1:
                    this.attend();
                    break;
                case 2:
                    this.quit();
                    break;
                case 3:
                    this.getInformation();
                    break;
                case 4:
                    this.viewInformation();
                    break;
                case 5:
                    this.viewAttendInformation();
                    break;
                case 6:
                    this.addNewEmployee();
                    break;
                case 7:
                    this.removeEmployee();
                    break;
                case 8:
                    this.changePassword();
                    break;
            }
        }        
    }

    private int getChoice(int identity) throws IOException {
        while(true) {
            try {
                System.out.println();
                int choice = 0;
                printUserMenu(identity);
                choice = Integer.parseInt(scanner.next());
                System.out.println();
                if (identity == 1 && !(landingEmployee instanceof Manager)) {
                    if (0 <= choice && choice <= 3) {
                        return choice;
                    }                  
                } else if (identity == 2 && landingEmployee instanceof Manager) {
                    if (0 <= choice && choice <= 8) {
                        return choice;
                    }                      
                } else {
                    System.err.println("Warning: Invalid Operation!");
                    return 0;
                }
                System.out.println("Invalid choice:  " + choice);
            } catch (NumberFormatException exception) {
                System.out.println(exception);
            }
        }
    }
*/
    public Employee getEmployee()
    {
      return landingEmployee;
    }
    public  void register1(String id, String password) throws IOException {
        try {
            var employee = company.getEmployee(id);
            if (employee != null && employee instanceof Manager) {
                if (((Manager) employee).getPassword().equals(password)) {
                    landingEmployee = employee;
                    Manager_menu true_demo = new Manager_menu(employee);
                    true_demo.show();
                    return;
                }
                else{
                    error_login fause_demo = new error_login();
                    fause_demo.show();
                }
            }
            else{
                error_login fause2_demo = new error_login();
                fause2_demo.show();
            }
        } catch (NumberFormatException exception) {
            System.out.println(exception);
        }
    }
    public  void register2(String id) throws IOException {
        try {
            var employee = company.getEmployee(id);
            if (employee != null && !(employee instanceof Manager)) {
                    landingEmployee = employee;
                    staff_menu true_demo = new staff_menu();
                    true_demo.show();
                    return;
                }
            else{
                error_login2 fause2_demo = new error_login2();
                fause2_demo.show();
            }
        } catch (NumberFormatException exception) {
            System.out.println(exception);
        }
    }
    public void askforLeave(Employee testemployee,String reason,String time1,String time2)throws IOException{
        afl_success afl_demo =new afl_success();
        afl_demo.show();
        IOController.leavingLeaveapplication(testemployee,reason,time1,time2);
    }

    public void message(Employee testemployee,String title,String content)throws IOException{
        msg_success msg_demo =new msg_success();
        msg_demo.show();
        IOController.leavingMessage(testemployee,title,content);
    }
    public void Deletemessage(String title) throws IOException {
        if(title!=null){
            if(IOController.removemessage(title)==1)
            {
                success_delete demo0=new success_delete();
                demo0.show();
            }
            else{
                delete_empty_title demo1=new delete_empty_title();
                demo1.show();
            }
        }
        else
        {
            error_delete_msg demo2=new error_delete_msg();
            demo2.show();
        }
    }

    public void attend() throws IOException {
        if (judgePunchingCard()) {
            System.out.println("Exception: You have attended today.");
            error_attend demo = new error_attend();
            demo.show();
            return;
        }
        else{
            success_attend demo = new success_attend();
            demo.show();
        }
        IOController.writeStart(landingEmployee);
    }

    public void quit() throws IOException {
        if (!judgePunchingCard()) {
            System.out.println("Exception: You haven't attended today.");
            error_quit demo = new error_quit();
            demo.show();
            return;
        }
        else{
            success_quit demo = new success_quit();
            demo.show();
        }
        IOController.writeEnd(landingEmployee);
    }

    public void getInformation() throws IOException {
        if (judgePunchingCard()) {
            hasattend demo = new hasattend();
            demo.show();
            System.out.println("Nice: You have attended today.");
        } else {
            notattend demo = new notattend();
            demo.show();
            System.out.println("Warning: You haven't attended today.");
        }
    }

    private boolean judgePunchingCard()  throws IOException {
        var historyList = IOController.readHistory();
        this.calendar = Calendar.getInstance();
        for (var line : historyList) {
            var array = line.split("#");
            if ((array[0].equals(landingEmployee.getId())) &&
                    (this.calendar.get(Calendar.DATE) == Integer.parseInt(array[3]))) {
                return true;
            }
        }
        return false;
    }

    public String viewInformation() {
        String ss="";
        if (landingEmployee instanceof Manager) {
            ss=((Manager) landingEmployee).viewAllEmployees();
        }
        return ss;
    }

    public void addNewEmployee1(String id,String name) throws IOException {
        try {
            if(id.length() != 0 && name.length()!=0) {
                var employee = new Employee(id, name, calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));
                ((Manager) landingEmployee).addEmployee(employee);
            }
            else{
                error_add fause_demo = new error_add();
                fause_demo.show();
            }
        } catch (NumberFormatException numberFormatException) {
            numberFormatException.printStackTrace();
        }
    }

    public void removeEmployee(String id) throws IOException {
        try {
            if(id.length() != 0) {
                //System.out.print("Please enter the newer's ID Number.\nNumber>");
                ((Manager) landingEmployee).fireEmployee(id);
            }
            else{
                error_delete demo = new error_delete();
                demo.show();
            }
        } catch (NumberFormatException numberFormatException) {
            numberFormatException.printStackTrace();
        }
    }

    public void changePassword(String oldpassword,String new1password,String new2password,Employee test1) throws IOException {
        try {
            //System.out.print(test1.getId());
            System.out.print("Please enter your password.\nOld Password>");
            IOController.judgePassword(oldpassword, (Manager)test1);
            System.out.print("Please enter your new password.\nNew Password>");
            var newString1 = new1password;
            System.out.print("Please enter your new password Again.\nNew Password>");
            var newString2 = new2password;
            if (newString1.equals(newString2)&&newString1.length()!=0) {
                IOController.changePassword(newString1, (Manager)test1);
                change_success demo =new change_success();
                demo.show();
            } else {
                System.out.println("Error! Input inconsistency!");
                change_error demo =new change_error();
                demo.show();
            }
        } catch (NumberFormatException numberFormatException) {
            numberFormatException.printStackTrace();
        }
    }
}


