package com.neu.staff.operator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.io.IOException;

import static com.neu.staff.operator.interface_login.heng;

public class interface_login2 {
    JFrame frame = new JFrame("login");
    JLabel a1 = new JLabel("id");
    JTextField b1 = new JTextField();
    JButton button = new JButton("OK");
    JPanel p1 = new JPanel();
    public interface_login2(){
        p1.setLayout(null);
        p1.add(a1);
        p1.add(b1);
        p1.add(button);
        a1.setBounds(40,45,35,30);
        b1.setBounds(100,45,200,30);
        button.setBounds(160,110,80,30);
        frame.add(p1,BorderLayout.CENTER);
        frame.setSize(400,200);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        b1.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent keyEvent) {

            }

            @Override
            public void keyPressed(KeyEvent keyEvent) {
                    if (keyEvent.getKeyCode()==KeyEvent.VK_ENTER) {
                        String id = b1.getText();
                        try {
                            heng.register2(id);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
                    }

            }

            @Override
            public void keyReleased(KeyEvent keyEvent) {

            }
        });
        button.addActionListener(actionEvent ->{
            String id = b1.getText();
            try {
                heng.register2(id);
            } catch (IOException e) {
                e.printStackTrace();
            }
            frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );
        });
    }
    public void show() { frame.setVisible(true); }
}
