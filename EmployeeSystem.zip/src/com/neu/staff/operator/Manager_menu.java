package com.neu.staff.operator;

import com.neu.staff.user.Employee;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.io.IOException;

import static com.neu.staff.operator.interface_login.heng;

public class Manager_menu {
    public  static interface_begin demo_begin = new interface_begin();
    JFrame frame = new JFrame("manager menu");
    JButton button0 = new JButton("Go Back Main Menu");
    JButton button1= new JButton("Register by punching card");
    JButton button2= new JButton("Quit by punching card");
    JButton button3 = new JButton("View Check-in Information");
    JButton button4= new JButton("View all attend information");
    JButton button5= new JButton("View all employees' information");
    JButton button6= new JButton("Add an employee in this company");
    JButton button7= new JButton("Fire an employee in this company");
    JButton button8= new JButton("Change password");
    JButton button9= new JButton("View all leave applications");
    JButton button10= new JButton("Message");
    JButton button11= new JButton("View MessageBoard");
    JButton button12= new JButton("Remove Message");
    JPanel p1 = new JPanel();

    public Manager_menu(Employee test){
        p1.setLayout(null);
        p1.add(button0);
        p1.add(button1);
        p1.add(button2);
        p1.add(button3);
        p1.add(button4);
        p1.add(button5);
        p1.add(button6);
        p1.add(button7);
        p1.add(button8);
        p1.add(button9);
        p1.add(button10);
        p1.add(button11);
        p1.add(button12);
        button0.setBounds(215,370,300,35);
        button1.setBounds(45,35,300,35);
        button2.setBounds(45,85,300,35);
        button3.setBounds(45,135,300,35);
        button4.setBounds(45,185,300,35);
        button5.setBounds(45,235,300,35);
        button6.setBounds(45,285,300,35);
        button7.setBounds(365,35,300,35);
        button8.setBounds(365,85,300,35);
        button9.setBounds(365,135,300,35);
        button10.setBounds(365,185,300,35);
        button11.setBounds(365,235,300,35);
        button12.setBounds(365,285,300,35);
        frame.add(p1,BorderLayout.CENTER);
        frame.setSize(725,500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        button0.addActionListener(actionEvent ->{
            frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING) );
            //demo_begin.show();
        });
        button1.addActionListener(actionEvent ->{
            try {
                heng.attend();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        button2.addActionListener(actionEvent ->{
            try {
                heng.quit();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        button3.addActionListener(actionEvent ->{
            try {
                heng.getInformation();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        button4.addActionListener(actionEvent ->{
            Manager_query1 demo4 = null;
            try {
                demo4 = new Manager_query1();
            } catch (IOException e) {
                e.printStackTrace();
            }
            demo4.show();
        });

        button5.addActionListener(actionEvent ->{
            Manager_query2 demo5 = null;
            try {
                demo5 = new Manager_query2();
            } catch (IOException e) {
                e.printStackTrace();
            }
            demo5.show();
        });

        button6.addActionListener(actionEvent ->{
            Manager_add demo6 =new Manager_add();
            demo6.show();
        });

        button7.addActionListener(actionEvent ->{
            Manager_delete demo7 =new Manager_delete();
            demo7.show();
        });

        button8.addActionListener(actionEvent ->{
            change_password demo7 =new change_password(test);
            demo7.show();
        });
        button9.addActionListener(actionEvent ->{
            all_leaveapplications demo8 = null;
            try {
                demo8 = new all_leaveapplications();
            } catch (IOException e) {
                e.printStackTrace();
            }
            demo8.show();
        });
        button10.addActionListener(actionEvent -> {
            message message_demo=new message(test);
            message_demo.show();
        });
        button11.addActionListener(actionEvent ->{
            message_board demo9 = null;
            try {
                demo9 = new message_board();
            } catch (IOException e) {
                e.printStackTrace();
            }
            demo9.show();
        });
        button12.addActionListener(actionEvent ->{
            remove_message demo10 =new remove_message();
            demo10.show();
        });
    }
    public void show() {
        frame.setVisible(true);
    }
}

