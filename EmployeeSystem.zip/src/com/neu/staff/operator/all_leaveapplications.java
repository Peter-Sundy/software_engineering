package com.neu.staff.operator;

import javax.swing.*;

import java.io.IOException;
import java.util.ArrayList;

import static com.neu.staff.operator.Constant.LEAVE_FILENAME;

public class all_leaveapplications {
    JFrame f = new JFrame("Leave applications");
    public static EmployeeSystem test = new EmployeeSystem();
   // ArrayList<String> al= test.readLeave();
    public all_leaveapplications()throws IOException {

        f.setSize(500, 600);
        f.setLocationRelativeTo(null);
        f.setLayout(null);
        JTextArea ta = new JTextArea();
        String ss="";
        for(String line:IOController.readLeaveapplication())
        {
            ss+=line+"\n";
        }
        ta.setText(ss);
        JScrollPane sp = new JScrollPane(ta);
        ta.setLineWrap(true);
        f.setContentPane(sp);

        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);


    }
    public void  show(){f.setVisible(true);}
}
